﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace PlayAssistant
{
    using AttributeListType = List<IReturnValue>;
    public class Character
    {
        /// Имя персонажа
        public string Name { get; set; }
        /// Статические свойства списка
        public static AttributeListType ListGeneralAttributes { get; set; } 
        /// Список со значениями свойств
        public List<Pair<string,string>> GeneralAttributesValue { get; set; }
        /// Свойства списка
        public AttributeListType ListAttributes { get; set; }
        /// Объявления имя 
        public Character(string name) { 
            Name = name; 
            ListAttributes = new AttributeListType(); 
            /// Проверка есть ли атрибуты
            if (ListGeneralAttributes == null) 
                /// Ввод атрибутов если их не было 
                ListGeneralAttributes = new AttributeListType(); 
            GeneralAttributesValue = new List<Pair<string, string>>(ListGeneralAttributes.Count());
        }
        /// Статистика персонажа 
        public void AddAttribute(IReturnValue stat) {
            if (stat.Title == "")
            {
                stat.Title = $"New Global Character Statistic {ListGeneralAttributes.Count() + ListAttributes.Count() + 1}";
            }
            ListAttributes.Add(stat);
            return;
        }
        
        public static void AddGeneralAttributes(IReturnValue stat)
        {
            if (stat.Title == "")
            {
                stat.Title = $"New Global Character Statistic {ListGeneralAttributes.Count() + 1}";
            }
            ListGeneralAttributes.Add(stat);
            return;
        }

        public AttributeListType GetAttributes()
        {
            var ans = new AttributeListType();
            if (ListGeneralAttributes != null) { 
                while (GeneralAttributesValue.Count < ListGeneralAttributes.Count)
                {
                    GeneralAttributesValue.Add(new Pair<string, string>("",""));
                }
                for(int i = 0; i < GeneralAttributesValue.Count; i++)
                {
                    ans.Add((IReturnValue)
                        Activator.CreateInstance(ListGeneralAttributes[i].GetType(),
                                                 GeneralAttributesValue[i].First,
                                                 GeneralAttributesValue[i].Second));
                }
            }
            if (ListAttributes != null)
            {
                foreach (var item in ListAttributes)
                {
                    ans.Add((IReturnValue)
                        Activator.CreateInstance(item.GetType(),
                                                 item.Title,
                                                 item.Value));
                }
            }
            return ans;
        }
        public void Refrash(AttributeListType tmplist)
        {
            for(int i = 0; i < GeneralAttributesValue.Count; i++)
            {
                GeneralAttributesValue[i] = new Pair<string, string>(tmplist[i].Value, tmplist[i].Title);
            }
            for(int i = GeneralAttributesValue.Count; i < tmplist.Count; i++)
            {
                ListAttributes[i - GeneralAttributesValue.Count].Value = tmplist[i].Value;
                ListAttributes[i - GeneralAttributesValue.Count].Title = tmplist[i].Title;
            }
        }
    }
}
