﻿namespace PlayAssistant
{
    public interface IReturnValue
    {
        string Title { get; set; }

        string Value { get; set; }
    }
}